It is a remainder software working on browser.

Functioning :
		It basically reminds the user/viewer ( who is surfing on website* ); after a fixed interval of time* ; i.e, how much time has been
		passed while surfing on that webpage. So that, user can decide, whether he/she has to continue or not !.
		
		example: facebook, youtube 
		
		Because , Generally while surfing on entertaining websites (i.e like listening songs on youtube or surfing on facebook), 
		we used to forget about "time passed".
		
		
		

How to use :-



		

			





websites* = generally entertaining and social media types websites

time* = this time is decided by the user.

for setting remainder to a particular website/webpages :- 



open "manifest.json"

goto line 15

 add website of your choice
 
 example: 
 	for one particular website
 		"matches": ["*://*.youtube.com/*"], 
 		
	for more than one, seperate each by ","
 		"matches": ["*://*.mozilla.org/*" , "*://*.youtube.com/*"],
 		
	or just copy website domain name
	and paste in same format.
	
	example:
		for "flipkart.com"
			"matches": ["*://*.mozilla.org/*" , "*://*.youtube.com/*" , "*://*.youtube.com/*"],
		replace one youtube.com with flipkart.com
			"matches": ["*://*.mozilla.org/*" , "*://*.youtube.com/*" , "*://*.flipkart.com/*"],
		

